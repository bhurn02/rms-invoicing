<?php
 // Create a new COM object for Crystal Reports
 $crApp = new COM("CrystalRuntime.Application") or die("Unable to create Crystal COM object");

